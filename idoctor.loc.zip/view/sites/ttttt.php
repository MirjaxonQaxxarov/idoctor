<div class="h-cliniks h-card">
                <h3>Oxirgi qo'shilgan shifohonalar</h3>
                <!-- Slider main container -->
                <div class="swiper mySwiper">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="sl-clinic-img" style="background-image: url('/assets/images/klinika1.jpg')">

                            </div>
                            <h3>Klinika nomi</h3>
                            <button class="btn">Batafsil</button>
                        </div>
                        <div class="swiper-slide">
                            <div class="sl-clinic-img" style="background-image: url('/assets/images/klinika2.png')">

                            </div>
                            <h3>Klinika nomi</h3>
                            <button class="btn">Batafsil</button>
                        </div>
                        <div class="swiper-slide">
                            <div class="sl-clinic-img" style="background-image: url('/assets/images/klinika.png')">

                            </div>
                            <h3>Klinika nomi</h3>
                            <button class="btn">Batafsil</button>
                        </div>
                    </div>
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-pagination"></div>
                </div>
                <div class="view-all" style="text-align:center; margin:25px">
                    <a href="#" class="btn">Barchasini ko'rish</a>
                </div>
            </div>
            <div class="h-cliniks h-card">
                <h3>Oxirgi qo'shilgan shifokorlar</h3>
                <!-- Slider main container -->
                <div class="swiper mySwiper">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="sl-clinic-img" style="background-image: url('/assets/images/doctor.jpg')">

                            </div>
                            <h3>Shifokor FISH</h3>
                            <button class="btn">Batafsil</button>
                        </div>
                        <div class="swiper-slide">
                            <div class="sl-clinic-img" style="background-image: url('/assets/images/doctor2.jpg')">

                            </div>
                            <h3>Shifokor FISH</h3>
                            <button class="btn">Batafsil</button>
                        </div>
                        <div class="swiper-slide">
                            <div class="sl-clinic-img" style="background-image: url('/assets/images/doctor3.jpg')">

                            </div>
                            <h3>Shifokor FISH</h3>
                            <button class="btn">Batafsil</button>
                        </div>
                    </div>
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-pagination"></div>
                </div>
                <div class="view-all" style="text-align:center; margin:25px">
                    <a href="#" class="btn">Barchasini ko'rish</a>
                </div>
            </div>