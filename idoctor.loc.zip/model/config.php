<?php

$link = new PDO('mysql:host=localhost;dbname=idoctor', 'root', 'root');

//$link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>
