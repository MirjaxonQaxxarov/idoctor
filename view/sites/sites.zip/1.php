
          <div class="right-bottom">
            <div class="right-body">
              <div class="body-top">
                <h2>Postlar</h2>
                <p>
                  <select class="minimal">
                    <option>-- Tanlang --</option>
                    <option>Toshkent viloyati</option>
                    <option>Samarqand viloyati</option>
                    <option>Farg'ona viloyati</option>
                    <option>Andijon viloyati</option>
                    <option>Qashqadaryo viloyati</option>
                    <option>Jizzax viloyati</option>
                    <option>Namangan viloyati</option>
                    <option>Buxoro viloyati</option>
                    <option>Navoiy viloyati</option>
                    <option>Surxondaryo viloyati</option>
                    <option>Sirdayro viloyati</option>
                    <option>Xorazm viloyati</option>
                    <option>Qoraqalpog'iston Respublikasi</option>
                  </select>
                  <img src="/assets/images/filter.png" alt="filter" />
                </p>
              </div>
              <div class="post-middle">
                <div class="post-cart">
                  <div class="post-image-container">
                    <img src="/assets/images/disease1.jpg" alt="disease" />
                  </div>
                  <div class="post-about">
                    <a href="#">
                      <h4>Karonavirus yana qaytmoqdami?</h4>
                      <p>
                        Lorem ipsum, dolor sit amet consectetur adipisicing
                        elit. cupiditate rerum, laboriosam deserunt, officiis
                        nulla cum, eius voluptates expedita magni dignissimos
                        facilis.
                      </p>
                      <p><span>Salomatlik </span>| 29.11.2022 y</p>
                    </a>
                  </div>
                </div>
                <div class="post-cart">
                  <div class="post-image-container">
                    <img src="/assets/images/disease2.jpg" alt="disease" />
                  </div>
                  <div class="post-about">
                    <a href="#">
                      <h4>
                        Hozirgi kundagi kasalliklar shamollash yoki gripp?
                      </h4>
                      <p>
                        Lorem ipsum, dolor sit amet consectetur adipisicing
                        elit. cupiditate rerum, laboriosam deserunt, officiis
                        nulla cum, eius voluptates expedita magni dignissimos
                        facilis.
                      </p>
                      <p><span>Salomatlik </span>| 29.11.2022 y</p>
                    </a>
                  </div>
                </div>
                <div class="post-cart">
                  <div class="post-image-container">
                    <img src="/assets/images/disease3.jpg" alt="disease" />
                  </div>
                  <div class="post-about">
                    <a href="#">
                      <h4>
                        Hozirgi ob-havo ba'zi kasalliklarni keltirib chiqarmoqda
                      </h4>
                      <p>
                        Lorem ipsum, dolor sit amet consectetur adipisicing
                        elit. cupiditate rerum, laboriosam deserunt, officiis
                        nulla cum, eius voluptates expedita magni dignissimos
                        facilis.
                      </p>
                      <p><span>Salomatlik </span>| 29.11.2022 y</p>
                    </a>
                  </div>
                </div>
              </div>
              <div class="body-ads"><h2>Reklama uchun joy...</h2></div>
              <div class="post-middle">
                <div class="post-cart">
                  <div class="post-image-container">
                    <img src="/assets/images/disease1.jpg" alt="disease" />
                  </div>
                  <div class="post-about">
                    <a href="#">
                      <h4>Karonavirus yana qaytmoqdami?</h4>
                      <p>
                        Lorem ipsum, dolor sit amet consectetur adipisicing
                        elit. cupiditate rerum, laboriosam deserunt, officiis
                        nulla cum, eius voluptates expedita magni dignissimos
                        facilis.
                      </p>
                      <p><span>Salomatlik </span>| 29.11.2022 y</p>
                    </a>
                  </div>
                </div>
                <div class="post-cart">
                  <div class="post-image-container">
                    <img src="/assets/images/disease2.jpg" alt="disease" />
                  </div>
                  <div class="post-about">
                    <a href="#">
                      <h4>
                        Hozirgi kundagi kasalliklar shamollash yoki gripp?
                      </h4>
                      <p>
                        Lorem ipsum, dolor sit amet consectetur adipisicing
                        elit. cupiditate rerum, laboriosam deserunt, officiis
                        nulla cum, eius voluptates expedita magni dignissimos
                        facilis.
                      </p>
                      <p><span>Salomatlik </span>| 29.11.2022 y</p>
                    </a>
                  </div>
                </div>
                <div class="post-cart">
                  <div class="post-image-container">
                    <img src="/assets/images/disease3.jpg" alt="disease" />
                  </div>
                  <div class="post-about">
                    <a href="#">
                      <h4>
                        Hozirgi ob-havo ba'zi kasalliklarni keltirib chiqarmoqda
                      </h4>
                      <p>
                        Lorem ipsum, dolor sit amet consectetur adipisicing
                        elit. cupiditate rerum, laboriosam deserunt, officiis
                        nulla cum, eius voluptates expedita magni dignissimos
                        facilis.
                      </p>
                      <p><span>Salomatlik </span>| 29.11.2022 y</p>
                    </a>
                  </div>
                </div>
              </div>
            </div>
