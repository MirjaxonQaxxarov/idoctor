<div class="right-bottom">
    <div class="right-body">
        <div class="body-top">
            <h2>Error Page</h2>

        </div>

        <div class="body-middle">

            <div class="middle-right" style="text-align: center;width: 100%;">
                <div class="cart-title">
                    <h1 style="font-size: 50px"> 404 </h1>
                    <p><i class="fa fa-exclamation-circle"></i>Unknown error the page.</p>
                    <div class="cart-btns">
                        <button style="margin-left: 45%" onclick="javascript:window.history.back();">Go Back</button>
                    </div>
                </div>

            </div>
        </div>
    </div>