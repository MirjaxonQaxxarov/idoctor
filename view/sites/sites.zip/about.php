
          <div class="right-bottom">
            <div class="right-body">
              <div class="body-top">
                <h2>Biz haqimizda</h2>
              </div>
              <div class="body-ads"><h2>Reklama uchun joy...</h2></div>
            </div>

